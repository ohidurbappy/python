This is the console package from googlecloudsdk, as used by Python Fire.
Python Fire does not accept pull requests modifying the console package; rather,
changes to console should go through the upstream project googlecloudsdk.
