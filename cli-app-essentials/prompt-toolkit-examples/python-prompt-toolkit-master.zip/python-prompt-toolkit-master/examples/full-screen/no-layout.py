#!/usr/bin/env python
"""
An empty full screen application without layout.
"""
from prompt_toolkit import Application

Application(full_screen=True).run()
